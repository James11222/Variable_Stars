# M15data2020
Raw Photometry data for Hoffman, Murakami, Zheng, et al. (2020).

Example methods to obtain/use our photometry data can be found in ```Usage.ipynb```.
